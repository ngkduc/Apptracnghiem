package com.el_rangxanh.test_11.monhoc;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.el_rangxanh.test_11.MainActivity;
import com.el_rangxanh.test_11.R;
import com.el_rangxanh.test_11.slide.ScreenSlideActivity;

import java.util.ArrayList;

public class MonhocFragment extends Fragment {
    ExamAdapter examAdapter;
    ListView lv_dethi;
    ArrayList<Exam> arr_exam = new ArrayList<Exam>();
    View view;
    String monhoc;

    public MonhocFragment(String monhoc){
        this.monhoc = monhoc;
    }


        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        switch (monhoc){
            case "anh":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Tiếng Anh");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "congDan":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Giáo Dục Công Dân");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "diaLy":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Địa Lý");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "hoa":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Hóa Học");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "lichSu":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Lịch Sử");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "ly":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Vật Lý");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "sinh":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Sinh Học");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "tin":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Tin Học");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
            case "toan":
                ((MainActivity) getActivity()).getSupportActionBar().setTitle("Toán");
                view = inflater.inflate(R.layout.fragment_toan, container, false);
                lv_dethi = view.findViewById(R.id.lvdethi);
                break;
        }

        arr_exam.add(new Exam("Đề khó"));
        arr_exam.add(new Exam("Đề dễ"));
        examAdapter=new ExamAdapter(getContext(),arr_exam);
        lv_dethi.setAdapter(examAdapter);

        lv_dethi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i=new Intent(getActivity(), ScreenSlideActivity.class);
                switch (monhoc){
                    case "anh":
                        i.putExtra("loaiMon","anh");
                        break;
                    case "congDan":
                        i.putExtra("loaiMon","congDan");
                        break;
                    case "diaLy":
                        i.putExtra("loaiMon","diaLy");
                        break;
                    case "hoa":
                        i.putExtra("loaiMon","hoa");
                        break;
                    case "lichSu":
                        i.putExtra("loaiMon","lichSu");
                        break;
                    case "ly":
                        i.putExtra("loaiMon","ly");
                        break;
                    case "sinh":
                        i.putExtra("loaiMon","sinh");
                        break;
                    case "tin":
                        i.putExtra("loaiMon","tin");
                        break;
                    case "toan":
                        i.putExtra("loaiMon","toan");
                }
                startActivity(i);
            }
        });
        return view;
    }
}
