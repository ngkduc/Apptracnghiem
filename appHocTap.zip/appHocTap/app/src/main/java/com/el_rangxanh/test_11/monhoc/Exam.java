package com.el_rangxanh.test_11.monhoc;

public class Exam {
    private String name;

    public Exam(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Exam() {

    }
}